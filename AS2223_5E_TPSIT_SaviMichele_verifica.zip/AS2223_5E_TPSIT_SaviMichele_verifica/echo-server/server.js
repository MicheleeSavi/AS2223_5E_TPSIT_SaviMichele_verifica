const WebSocket = require('ws');
const wsServer = new WebSocket.Server({ port: 5000 });

console.log("Il Server è attivo e aspetta pacchetti sulla porta " + wsServer.options.port);

let operation = "none";
var y = 0;
wsServer.on('connection', (socket) => {
    console.log("un client si è appena connesso");
    socket.send("la tua connessione è stata accettata dal server");
    socket.on('message', (msg) => {
        console.log("Ho ricevuto un messaggio: " + msg);
            switch(''+msg) {
                case "moltiplica":
                    y = 1;
                    console.log("Hai scelto moltiplica");
                    break;
                case "raddoppia":
                    y = 2;
                    console.log("Hai scelto raddoppia");
                    break;
                case "fattoriale":
                    y = 3;
                    console.log("Hai scelto fattoriale");
                    break;
                default:
                    console.log("La stringa inserita non corrisponde a moltiplica/raddopia/fattoriale");
                    socket.send("no");
                    break;
            }

            switch(y)
            {
                case 1:
                    if(isNaN(msg) == false)
                    {
                        msg *= msg;
                        console.log("Il risultato è: " + msg);
                    }
                    break;
                case 2:
                    if(isNaN(msg) == false)
                    {
                        msg *= 2;
                        console.log("Il risultato è: " + msg);
                    }
                    break;
                case 3:
                    if(isNaN(msg) == false)
                    {
                        console.log("Il risultato è: " + fattoriale(numero));
                    }
                    break;
                default:
                    break;
                }
    });
});

function fattoriale(numero) {
    var fat = 1;
    for(let i = 1; i <= numero; i++) {
        fat = fat * i;
    }
    return fat;
}