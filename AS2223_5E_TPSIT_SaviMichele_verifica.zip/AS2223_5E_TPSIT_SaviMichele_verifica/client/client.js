const WebSocket = require('ws');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

var y = 0;
let msg = "si";

const ws = new WebSocket('ws://localhost:5000');

ws.on('message', (msg) => {
   if(y === 0)
   {
      console.log("Connesso al server");
      rl.question('Scegli un operazione(moltiplica/raddoppia/fattoriale): ', (answer) => {
          ws.send(answer);
      });
      y = 1;
   }
   else
   {
      rl.question('Inserisci un numero: ', (answer) => {
         ws.send(answer);
      });
   }
});